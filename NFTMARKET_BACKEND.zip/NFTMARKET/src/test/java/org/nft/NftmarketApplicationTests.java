package org.nft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NftmarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
