package org.nft.entities;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="users")
public class Users implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	private long id;
	private long user_followings_size;
	private String SFirstname;
	private String SLastname;
	private float volume;
	private float prix_plancher;
	private String SBIO;
	private String profil;
	private String routing;
	private String background;
	private List<Product> prods; 
	private List<Panier> paniers;
	
	public List<Panier> getPaniers() {
		return paniers;
	}

	public void setPaniers(List<Panier> paniers) {
		this.paniers = paniers;
	}

	public Users() {
		super();

	}

	public Users(long id, long user_followings_size, String sFirstname, String sLastname, float volume,
			float prix_plancher, String sBIO, String profil, String routing, String background) {
		super();
		this.id = id;
		this.user_followings_size = user_followings_size;
		SFirstname = sFirstname;
		SLastname = sLastname;
		this.volume = volume;
		this.prix_plancher = prix_plancher;
		SBIO = sBIO;
		this.profil = profil;
		this.routing = routing;
		this.background = background;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUser_followings_size() {
		return user_followings_size;
	}

	public void setUser_followings_size(long user_followings_size) {
		this.user_followings_size = user_followings_size;
	}

	public String getSFirstname() {
		return SFirstname;
	}

	public void setSFirstname(String sFirstname) {
		SFirstname = sFirstname;
	}

	public String getSLastname() {
		return SLastname;
	}

	public void setSLastname(String sLastname) {
		SLastname = sLastname;
	}

	public float getVolume() {
		return volume;
	}

	public void setVolume(float volume) {
		this.volume = volume;
	}

	public float getPrix_plancher() {
		return prix_plancher;
	}

	public void setPrix_plancher(float prix_plancher) {
		this.prix_plancher = prix_plancher;
	}

	public String getSBIO() {
		return SBIO;
	}

	public void setSBIO(String sBIO) {
		SBIO = sBIO;
	}

	public String getProfil() {
		return profil;
	}

	public void setProfil(String profil) {
		this.profil = profil;
	}

	public String getRouting() {
		return routing;
	}

	public void setRouting(String routing) {
		this.routing = routing;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public List<Product> getProds() {
		return prods;
	}

	public void setProds(List<Product> prods) {
		this.prods = prods;
	}

	public void addProducts(List<Product> book) {
		this.prods.addAll(book);
		
	}

	public void deleteProducts(List<Product> book) {
		this.prods.removeAll(book);
		
	}
	
}
