package org.nft.entities;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Panier")
public class Panier implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	private int id_panier;
	private Users user;
	private List<Product> tobuy;
	public Panier() {
		super();

		user = new Users();
	}

	public Panier(int id_panier, Users user) {
		super();
		this.id_panier = id_panier;
		this.user = user;
	}

	public int getId_panier() {
		return id_panier;
	}

	public void setId_panier(int id_panier) {
		this.id_panier = id_panier;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public List<Product> getTobuy() {
		return tobuy;
	}

	public void setTobuy(List<Product> tobuy) {
		this.tobuy = tobuy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void addProducts(List<Product> book) {
		this.tobuy.addAll(book);
	}

	public void deleteProducts(Optional<Product> product) {
		 this.tobuy.remove(product);
	}
	
}
