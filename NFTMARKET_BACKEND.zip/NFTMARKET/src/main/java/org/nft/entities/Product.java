package org.nft.entities;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Document(collection="product")
public class Product implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private long id_prod;
	private String name;
	private String description;
	private String imageUrl;
	private float solde_price;
	private float regular_price;
	private List<Panier> paniers;
	public List<Panier> getPaniers() {
		return paniers;
	}
	public void setPaniers(List<Panier> paniers) {
		this.paniers = paniers;
	}
	public Product() {
		super();

	}
	public Product(long id_prod, String name, String description, String imageUrl, float solde_price,
			float regular_price) {
		super();
		this.id_prod = id_prod;
		this.name = name;
		this.description = description;
		this.imageUrl = imageUrl;
		this.solde_price = solde_price;
		this.regular_price = regular_price;
	}
	public long getId_prod() {
		return id_prod;
	}
	public void setId_prod(long id_prod) {
		this.id_prod = id_prod;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public float getSolde_price() {
		return solde_price;
	}
	public void setSolde_price(float solde_price) {
		this.solde_price = solde_price;
	}
	public float getRegular_price() {
		return regular_price;
	}
	public void setRegular_price(float regular_price) {
		this.regular_price = regular_price;
	}
	@Override
	public String toString() {
		return "Product [id_prod=" + id_prod + ", name=" + name + ", description=" + description + ", imageUrl="
				+ imageUrl + ", solde_price=" + solde_price + ", regular_price=" + regular_price + "]";
	}
	public void addPaniers(List<Panier> book) {
		this.paniers.addAll(book);
	}
}