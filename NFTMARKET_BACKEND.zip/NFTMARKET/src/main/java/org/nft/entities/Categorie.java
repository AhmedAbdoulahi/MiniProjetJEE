package org.nft.entities;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
 
@Document(collection="categorie")
public class Categorie implements Serializable{
   
	private static final long serialVersionUID = 1L;
	@Id
	private long id_cat;
	private String libelle;
	private String slug;
    private List<Product> products;
    
	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Categorie() {
		super();

	}


	public Categorie(long id_cat, String libelle, String slug, List<Product> products) {
		super();
		this.id_cat = id_cat;
		this.libelle = libelle;
		this.slug = slug;
		this.products = products;
	}

	public long getId_cat() {
		return id_cat;
	}

	public void setId_cat(long id_cat) {
		this.id_cat = id_cat;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public void addProducts(List<Product> book) {
		this.products.addAll(book);
	}
	public void deleteProducts(List<Product> book) {
		this.products.removeAll(book);
	}
}