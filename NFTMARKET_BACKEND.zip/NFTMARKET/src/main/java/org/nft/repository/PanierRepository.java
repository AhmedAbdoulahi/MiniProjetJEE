package org.nft.repository;

import org.nft.entities.Panier;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PanierRepository extends MongoRepository<Panier, Integer>{

	/*
	List<Panier> getAllPaniers();

	void savePanier(Panier panier);

	void savePanier(List<Panier> panier);

	void deletePanier();

	void deletePanierById(Integer id_panier);

	Panier updatePanier( Panier panier);*/
}
