package org.nft.repository;


import java.util.Optional;

import org.nft.entities.Categorie;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface CategorieRepository extends MongoRepository<Categorie, Integer>{
    
	Optional<Categorie> findByLibelle(String libelle);
	void deleteByLibelle(String libelle);
	/*

	void saveCategorieById( Categorie categorie);

	void saveCategorieById(List<Categorie> categorie);

	void deleteCategorieById(Integer id_cat);

	Categorie updateCategorie( Categorie categorie);*/

}