package org.nft.repository;

import java.util.List;
import java.util.Optional;

import org.nft.entities.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends MongoRepository<Product, Integer>{

	List<Product> findProductByName(String name);

	void deleteByName(String libelle);

	Optional<Product> findByName(String libelle);
	
	/*
	List<Product> getAllProducts();

	Optional<Product> getProductById(Integer id_prod);

	void saveProduct( Product product);

	void saveProduct(List<Product> product);

	void deleteProductById(Integer id_prod);

	Product updateProduct( Product product);*/

}
