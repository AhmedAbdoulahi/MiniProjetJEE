package org.nft.repository;

import java.util.Optional;

import org.nft.entities.Users;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRepository extends MongoRepository<Users, Integer>{

	Optional<Users> findBySLastname(String libelle);

	void deleteBySLastname(String libelle);

	/*
	List<Users> getAllUsers();

	Optional<Users> getUserById(Integer id_user);

	void saveUserById( Users users);

	void saveUserById(List<Users> users);

	void deleteUserById(Integer id_user);

	Users updatePUser( Users users);*/
}
