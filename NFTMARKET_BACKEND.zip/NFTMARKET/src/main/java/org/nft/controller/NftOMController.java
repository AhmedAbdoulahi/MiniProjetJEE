package org.nft.controller;
import java.util.List;
import java.util.Optional;

import org.nft.entities.Categorie;
import org.nft.entities.Panier;
import org.nft.entities.Product;
import org.nft.entities.Users;
import org.nft.repository.CategorieRepository;
import org.nft.repository.PanierRepository;
import org.nft.repository.ProductRepository;
import org.nft.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order-service")
public class NftOMController {

	@Autowired
	private CategorieRepository categorieRepository;
	@Autowired
	private PanierRepository panierRepository;
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private ProductRepository productRepository;
	
	@PostMapping("/addCategorie")
	public String saveCategorie(@RequestBody Categorie book) {
		categorieRepository.save(book);
		return "Added book with id : " + book.getId_cat();
	}

	@GetMapping("/findAllCategories")
	public List<Categorie> getAllCategories() {
		return categorieRepository.findAll();
	}
	@GetMapping("/findCategorie/{libelle}")
	public Optional<Categorie> getCategorie(@PathVariable String libelle) {
		try {
			return categorieRepository.findById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			return categorieRepository.findByLibelle(libelle);
		} 
	}
	@DeleteMapping("/deteteCategorie/{libelle}")
	public void deleteCategorie(@PathVariable String libelle) {
		try {
			  categorieRepository.deleteById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			  categorieRepository.deleteByLibelle(libelle);
		} 
	}
	@PostMapping("/addProductToCategorie/{libelle}")
	public String addProductToCategorie(@RequestBody List<Product> book,@PathVariable String libelle) {
		Categorie cat = new Categorie();
		try {
			 cat = categorieRepository.findById(Integer.parseInt(libelle)).get();  
		}
		catch(Exception e) {
			 cat = categorieRepository.findByLibelle(libelle).get(); 
		} 
		cat.addProducts(book);
		deleteCategorie(libelle);
		productRepository.saveAll(book);
		categorieRepository.save(cat);
		return"Added book with id : " ;
	}
	@DeleteMapping("/deteteProdfromCategorie/{libelle}")
	public String deleteProdfromCategorie(@PathVariable String libelle, @RequestBody String name) {
		Categorie cat = new Categorie();
		try {
			 cat = categorieRepository.findById(Integer.parseInt(libelle)).get();  
		}
		catch(Exception e) {
			 cat = categorieRepository.findByLibelle(libelle).get(); 
		} 
		cat.deleteProducts(productRepository.findProductByName(name));
		productRepository.deleteAll(productRepository.findProductByName(name));
		deleteCategorie(libelle);
		categorieRepository.save(cat);
		return"Added book with id : " ;
	}
	@GetMapping("/findAllProdsByCategorie/{libelle}")
	public List<Product> getAllProdsByCategorie(@PathVariable String libelle) {
		try {
			 return categorieRepository.findById(Integer.parseInt(libelle)).get().getProducts(); 
		}
		catch(Exception e) {
			 return categorieRepository.findByLibelle(libelle).get().getProducts(); 
		} 
	}
	
	@PostMapping("/addProduct")
	public String saveProduct(@RequestBody Product book) {
		productRepository.save(book);
		return "Added book with id : " + book.getId_prod();
	}

	@GetMapping("/findAllProducts")
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}
	@GetMapping("/findProduct/{libelle}")
	public Optional<Product> getProduct(@PathVariable String libelle) {
		try {
			return productRepository.findById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			return productRepository.findByName(libelle);
		} 
	}
	@DeleteMapping("/deteteProduct/{libelle}")
	public void deleteProduct(@PathVariable String libelle) {
		try {
			productRepository.deleteById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			productRepository.deleteByName(libelle);
		} 
		
	}
	@DeleteMapping("/deteteProduct/{libelle}")
	public void deletePanier(@PathVariable String libelle) {
		 
			panierRepository.deleteById(Integer.parseInt(libelle));
		  
	}
	@PostMapping("/addProductToPanier/{libelle}")
	public String addProductToPanier(@RequestBody List<Product> book,@PathVariable String libelle) {
		Panier panier = new Panier();
		panier = panierRepository.findById(Integer.parseInt(libelle)).get();
		panier.addProducts(book);
 		deletePanier(libelle);
		panierRepository.save(panier);
		return"Added book with id : " ;
	}
	@DeleteMapping("/deteteProductfromPanier/{libelle}")
	public String deteteProductfromPanier(@PathVariable String libelle, @RequestBody String name) {
		Panier panier = new Panier();
		panier = panierRepository.findById(Integer.parseInt(libelle)).get();
		panier.deleteProducts(getProduct(name));
		deletePanier(libelle);
		panierRepository.save(panier);
		return"Added book with id : " ;
	}
	@GetMapping("/findAllProdsPanier/{libelle}")
	public List<Product> getAllProdsPanier(@PathVariable String libelle) {
		 
			 return panierRepository.findById(Integer.parseInt(libelle)).get().getTobuy(); 
		  
	}
	@PostMapping("/addUser")
	public String saveUser(@RequestBody Users book) {
		usersRepository.save(book);
		return "Added book with id : " + book.getId();
	}

	@GetMapping("/findAllUsers")
	public List<Users> getAllUsers() {
		return usersRepository.findAll();
	}
	@GetMapping("/findUser/{libelle}")
	public Optional<Users> getUser(@PathVariable String libelle) {
		try {
			return usersRepository.findById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			return usersRepository.findBySLastname(libelle);
		} 
	}
	@DeleteMapping("/deteteUsers/{libelle}")
	public void deleteUsers(@PathVariable String libelle) {
		try {
			  usersRepository.deleteById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			  usersRepository.deleteBySLastname(libelle);
		} 
	}
	@PostMapping("/addProductToUser/{libelle}")
	public String addProductToUser(@RequestBody List<Product> book,@PathVariable String libelle) {
		Users user = new Users();
		try {
			 user = usersRepository.findById(Integer.parseInt(libelle)).get();  
		}
		catch(Exception e) {
			 user = usersRepository.findBySLastname(libelle).get(); 
		} 
		user.addProducts(book);
		deleteUser(libelle);
		//productRepository.saveAll(book);
		usersRepository.save(user);
		return"Added book with id : " ;
	}
	@DeleteMapping("/deteteProdfromUser/{libelle}")
	public String deleteProdfromUser(@PathVariable String libelle, @RequestBody String name) {
		Users user = new Users();
		try {
			 user = usersRepository.findById(Integer.parseInt(libelle)).get();  
		}
		catch(Exception e) {
			 user = usersRepository.findBySLastname(libelle).get(); 
		}  
		user.deleteProducts(productRepository.findProductByName(name));
		
		deleteUser(libelle);
		usersRepository.save(user);
		return"Added book with id : " ;
	}
	@DeleteMapping("/deteteUsers/{libelle}")
	public void deleteUser(@PathVariable String libelle) {
		try {
			  usersRepository.deleteById(Integer.parseInt(libelle));
		}
		catch(Exception e) {
			  usersRepository.deleteBySLastname(libelle);
		} 
	}
}
