package org.nft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NftmarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(NftmarketApplication.class, args);
	}

}
